/*
 * Copyright (C) 2024 Hangzhou C-SKY MicroSystems Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License")
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef __REMOTE_MONITOR_H__
#define __REMOTE_MONITOR_H__

struct server;

void remote_moniter_set_current_server(struct server *server);

void remote_moniter_message_out(const char *str, ...);

void remote_set_detech_resume_target_switch(int on);

#endif
